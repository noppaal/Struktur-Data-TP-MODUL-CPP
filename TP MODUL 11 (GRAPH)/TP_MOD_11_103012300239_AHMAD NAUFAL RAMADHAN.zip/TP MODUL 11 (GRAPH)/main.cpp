#include "graph.h"
#include <iostream>

using namespace std;

int main(){
    graph G;
    buildGraph_103012300239(G);
    show_103012300239(G);

    return 0;
}
